﻿using System;
using System.Collections;
using SimpleLList;

namespace Driver
{
    class Customer : IComparable<Customer>, IEnumerable

    {
        public Customer(int intAccountNumber)
        {
            AccountNumber = intAccountNumber;
        }

        public Customer(string strFirst, string strLast, string strAddress, string strCity,
            string strState, string strZip, string strHomePhone, string strCellPhone,
            int intAccountNumber, decimal decBalance)
        {
            FirstName = strFirst;
            LastName = strLast;
            Address = strAddress;
            City = strCity;
            State = strState;
            Zip = strZip;
            HomePhone = strHomePhone;
            CellPhone = strHomePhone;
            AccountNumber = intAccountNumber;
            Balance = decBalance;
        }

        public string FirstName
        { get; set; }
        public string LastName
        { get; set; }
        public string Address
        { get; set; }
        public string City
        { get; set; }
        public string State
        { get; set; }
        public string Zip
        { get; set; }
        public string HomePhone
        { get; set; }
        public string CellPhone
        { get; set; }
        public int AccountNumber
        { get; set; }
        public decimal Balance
        { get; set; }

        public string ContactInfo()
        {
            string strTemp = this.ToString();
            strTemp += string.Format("\n{0}: ({1}) {2}-{3}", "Home Phone", HomePhone.Substring(0, 3),
                HomePhone.Substring(3, 3), HomePhone.Substring(6, 4));
            strTemp += string.Format("\n{0}: ({1}) {2}-{3}", "Cell Phone", CellPhone.Substring(0, 3),
                CellPhone.Substring(3, 3), CellPhone.Substring(6, 4));
            strTemp += "\n";
            return strTemp;
        }
        public override string ToString()
        {
            string strTemp = "Account: \t" + AccountNumber.ToString();
            //strTemp += "\nName: \t" + FirstName + " " + LastName;
            //strTemp += "\nAddress: \t" + Address;
            //strTemp += "\n\t" + City + ", " + State + "  " + Zip;
            //strTemp += "\n\nBalance: \t" + String.Format("{0:C}", Balance.ToString());
            return strTemp;
        }

        public int CompareTo(Customer objCompare)
        {
            return this.AccountNumber.CompareTo((objCompare).AccountNumber);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)this;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            NodeList<Customer> myList = new NodeList<Customer>();
            Customer cust = new Customer(333);
            myList.Insert(cust);
            Customer cust2 = new Customer(444);
            myList.Insert(cust2);
            Customer cust3 = new Customer(777);
            myList.Insert(cust3);
            Customer cust4 = new Customer(111);
            myList.Insert(cust4);
            Customer cust5 = new Customer(222);
            myList.Insert(cust5);


            foreach (Customer c in myList)
                Console.WriteLine(c.ToString());
            Console.WriteLine("Count is {0}", myList.Count);
            Console.WriteLine("Item[2] is {0}", myList[2]);
            Console.WriteLine("MyList contains cust3 is {0}", myList.FindNode(cust3) != null);
            Console.WriteLine("Remove cust3...");
            myList.Delete(cust3);
            Console.WriteLine("Count is {0}", myList.Count);
            foreach (Customer c in myList)
                Console.WriteLine(c.ToString());
            Console.WriteLine("MyList contains cust3 is {0}", myList.FindNode(cust3) != null);
            Console.WriteLine("Remove cust4...");
            myList.Delete(cust4);
            Console.WriteLine("Count is {0}", myList.Count);
            foreach (Customer c in myList)
                Console.WriteLine(c.ToString());

            Console.WriteLine("MyList contains cust3 is {0}", myList.FindNode(cust3) != null);
            Console.WriteLine("MyList ...");
            try
            {
                myList.Delete(cust3);
            }
            catch (NullReferenceException)
            {
                Console.WriteLine("Index was out of range.");
            }
            Console.WriteLine("Count is {0}", myList.Count);
            foreach (Customer c in myList)
                Console.WriteLine(c.ToString());
            Console.WriteLine("MyList contains cust4 is {0}", myList.FindNode(cust4) != null);

            Console.WriteLine("Remove cust4...");
            try
            {
                myList.Delete(cust4);
            }
            catch (NullReferenceException m)
            {
                Console.WriteLine("Error: " + m.Message);
            }
            Console.WriteLine("Count is {0}", myList.Count);
            Console.WriteLine("MyList contains cust2 is {0}", myList.FindNode(cust2) != null);

            Console.WriteLine("Count is {0}", myList.Count);
            foreach (Customer c in myList)
                Console.WriteLine(c.ToString());

            Console.WriteLine("Count is {0}", myList.Count);
            foreach (Customer c in myList)
                Console.WriteLine(c.ToString());

            Console.WriteLine("Remove list[0]...");
            try
            {
                myList.Delete(myList[0]);
            }
            catch (NullReferenceException m)
            {
                Console.WriteLine("Error: " + m.Message);
            }
            Console.WriteLine("Count is {0}", myList.Count);
            Console.WriteLine("RemoveAt(0)...");
            try
            {
                myList.Delete(myList[0]);
            }
            catch (NullReferenceException m)
            {
                Console.WriteLine("Error: " + m.Message);
            }
            Console.WriteLine("Count is {0}", myList.Count);
            Console.WriteLine("RemoveAt(0)...");
            try
            {
                myList.Delete(myList[0]);
            }
            catch (NullReferenceException m)
            {
                Console.WriteLine("Error: " + m.Message);
            }
            Console.WriteLine("Count is {0}", myList.Count);
            Console.WriteLine("RemoveAt(0)...");
            try
            {
                myList.Delete(myList[0]);
            }
            catch (NullReferenceException m)
            {
                Console.WriteLine("Error: " + m.Message);
            }
            Console.WriteLine("Count is {0}", myList.Count);
            Console.WriteLine("RemoveAt(0)...");
            try
            {
                myList.Delete(myList[0]);
            }
            catch (NullReferenceException m)
            {
                Console.WriteLine("Error: " + m.Message);
            }
            Console.WriteLine("Count is {0}", myList.Count);
            Console.ReadKey();



        }
    }
}
