﻿using System;

namespace SimpleLList
{
    [Serializable]
    public class Node<T>
    {
        public Node(T nodeData)
        {
            Data = nodeData;
            Next = null;
        }

        public T Data { get; set; }
        public Node<T> Next { get; set; }
    }
}
