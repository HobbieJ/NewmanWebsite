# Advanced Programming Topics

This is the class that introduced me to combining databases with the programs I have been creating in both Programming 1
and Programming 2. However, as of now, I've taken this class before the actual database class. Trying to teach myself the extreme
basics of databasing without a solid foundation is interesting, but at the very least, it's teaching me to work on my feet and learn
something and do something when I don't have everything available to me. It also taught me a lot of about self-research as well.

I will also say that this was a fairly difficult class. Some of the work that you see above involves MVC, which I feel
was difficult due to Microsoft and the .NET environment working a lot in the background to create the webpages, without exactly
telling you what is happening. The Halloween project and the Multipage project are especially standouts when thinking about the
work done in the class. However, there was also a really fun chat app that we made near the end of the semester that showcased the power
using network connections within your code you could create. I always keep a copy of that code not only for the novelty, but to
show me how to make a basic chat app in the future as well.