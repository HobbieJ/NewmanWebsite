﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Halloween_MVC_1.Models.ViewModels
{
    public class CartViewModel : IEnumerable<ProductViewModel>
    {
        public List<ProductViewModel> Cart { get; set; }
        public ProductViewModel AddedProduct { get; set; }
        public IEnumerator<ProductViewModel> GetEnumerator()
        {
            return ((IEnumerable<ProductViewModel>) Cart).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}