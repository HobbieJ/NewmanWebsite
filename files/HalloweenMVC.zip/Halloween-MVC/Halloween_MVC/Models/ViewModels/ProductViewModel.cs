﻿namespace Halloween_MVC_1.Models.ViewModels
{
    public class ProductViewModel
    {
        public string ProductID { get; set; }
        public string Name { get; set; }
        public string ShortDescription { get; set; }
        public string LongDescription { get; set; }
        public decimal UnitPrice { get; set; }
        public string ImageFile { get; set; }
        public int Quantity { get; set; }
        public string LongCategoryDescription { get; set; }

        public string Display()
        {
            return string.Format("{0} ({1} at {2:C} each)", Name, Quantity.ToString(), UnitPrice);
        }
    }
}