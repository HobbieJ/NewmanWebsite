﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Halloween_MVC_1.Models
{
    public class ContactModel
    {
        public string Email => "info@halloweensuperstore.com";
        public string Phone => "1-800-123-4567";
        public string Fax => "1-800-123-4568";
        public string Address => "1234 Main Street, Anytown, USA";

        public List<string> SocialMediaUrls
        {
            get
            {
                List<string> urls = new List<string>();
                urls.Add("http://www.facebook.com/halloweensuperstore");
                urls.Add("http://www.twitter.com/halloweensuperstore");
                return urls;
            }
        }
    }
}