﻿using Halloween_MVC_1.Models.ViewModels;
using System.Collections.Generic;
using System.Linq;

namespace Halloween_MVC_1.Models
{
    public class OrderModel
    {
        private List<ProductViewModel> products;

        public List<Product> GetAllProductsFromDataStore()
        {
            HalloweenDataEntities dataContext = new HalloweenDataEntities();
            return dataContext.Products.OrderBy(p => p.Name).ToList();
        }
        public Product GetProductByIDFromDataStore(string id)
        {
            HalloweenDataEntities dataContext = new HalloweenDataEntities();
            return dataContext.Products.FirstOrDefault(p => p.ProductID == id);
        }

        public ProductViewModel ConvertToViewModel(Product p)
        {
            HalloweenDataEntities dataContext = new HalloweenDataEntities();
            ProductViewModel model = new ProductViewModel
            {
                ProductID = p.ProductID,
                ImageFile = p.ImageFile,
                LongDescription = p.LongDescription,
                ShortDescription = p.ShortDescription,
                Name = p.Name,
                UnitPrice = p.UnitPrice,
                LongCategoryDescription = dataContext.Categories.FirstOrDefault(c => c.CategoryID == p.CategoryID)
                .LongName.ToString()
            };
            return model;

        }
        public List<ProductViewModel> GetAllProducts()
        {
            List<ProductViewModel> productModels = new List<ProductViewModel>();
            List<Product> productsList = GetAllProductsFromDataStore();
            foreach (Product p in productsList)
                productModels.Add(ConvertToViewModel(p));
            return productModels;

        }
        public List<ProductViewModel> GetProductsList()
        {
            if (products == null)
                products = GetAllProducts();
            return products;
        }
        public ProductViewModel GetSelectedProduct(string id)
        {
            if (products == null)
                return ConvertToViewModel(GetProductByIDFromDataStore(id));
            else
                return products.FirstOrDefault(p => p.ProductID == id);
        }
        public OrderViewModel GetOrderInfo(string id)
        {
            OrderViewModel order = new OrderViewModel { SelectedProduct = GetSelectedProduct(id) };
            return order;
        }
    }
}