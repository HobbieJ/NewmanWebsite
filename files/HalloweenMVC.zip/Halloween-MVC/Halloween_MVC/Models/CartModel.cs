﻿using Halloween_MVC_1.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Halloween_MVC_1.Models
{
    public class CartModel
    {
        private List<ProductViewModel> GetCartFromDataStore()
        {
            List<ProductViewModel> cart;
            cart = (List<ProductViewModel>)(HttpContext.Current.Session["cart"]);
            if (cart == null)
            {
                cart = new List<ProductViewModel>();
                HttpContext.Current.Session["cart"] = cart;
            }
            return cart;
        }
        private void AddItemToDataStore(CartViewModel model)
        {
            model.Cart.Add(model.AddedProduct);
        }

        private ProductViewModel GetSelectedProduct(string id)
        {
            OrderModel order = new OrderModel();
            return order.GetSelectedProduct(id);
        }

        public CartViewModel GetCart(string id = "")
        {
            CartViewModel model = new CartViewModel();
            model.Cart = GetCartFromDataStore();
            if (!string.IsNullOrEmpty(id))
                model.AddedProduct = GetSelectedProduct(id);

            return model;
        }
        public void AddToCart(CartViewModel model)
        {
            if (model.AddedProduct.ProductID != null)
            {
                string id = model.AddedProduct.ProductID;
                ProductViewModel inCart = model.Cart.FirstOrDefault(p => p.ProductID == id);
                if (inCart == null)
                    AddItemToDataStore(model);
                else
                    inCart.Quantity += model.AddedProduct.Quantity;
            }
        }

        public void RemoveFromCart(string id = "")
        {
            if (string.IsNullOrEmpty(id)) return;

            List<ProductViewModel> cart;
            cart = (List<ProductViewModel>)(HttpContext.Current.Session["cart"]);
            if (cart == null) return;

            foreach (ProductViewModel p in cart.Where(p => p.ProductID == id))
            {
                cart.Remove(p);
            }
        }
    }
}