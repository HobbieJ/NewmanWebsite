﻿using Halloween_MVC_1.Models;
using Halloween_MVC_1.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Halloween_MVC_1.Controllers
{
    public class OrderController : Controller
    {
        private OrderModel order = new OrderModel();
        // GET: Order
        [HttpGet]
        public ActionResult Index(string id)
        {
            //get list for drop down either from TempData or from order data
            SelectList products = (SelectList)TempData["products"];
            if (products == null)
            {
                List<ProductViewModel> list = order.GetProductsList();
                products = new SelectList(list, "ProductId", "Name", id) ;
            }
            //if no URL parm, get first product from list and refresh
            if (string.IsNullOrEmpty(id))
            {
                id = products.ElementAt(0).Value;
                TempData["products"] = products;
                //redirect to action - cause the browser to make Get request to the specified action
                return RedirectToAction("Index", "Order", new { id });
            }
            else
            {
                //get the selected product and return in view method
                OrderViewModel model = order.GetOrderInfo(id);
                model.ProductsList = products;
                model.SelectedProduct.Quantity = 1;
                return View(model);
            }
 
        }

        [HttpPost]
        //RedirectToAction - instead of making a post back to the server, 
        //cause the browser to make a GET request to the specified action
        public RedirectToRouteResult Index(FormCollection collection)
        {
            string pID = collection["ddlProducts"];
            return RedirectToAction("Index", "Order", new { id = pID });
        }
    }
}