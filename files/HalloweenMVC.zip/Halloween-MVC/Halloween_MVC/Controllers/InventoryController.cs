﻿using Halloween_MVC_1.Models;
using Halloween_MVC_1.Models.ViewModels;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Halloween_MVC_1.Controllers
{
    public class InventoryController : Controller
    {
        public ActionResult Index()
        {
            OrderModel model = new OrderModel();
            List<ProductViewModel> prodList = model.GetProductsList();
            return View(prodList);
        }
    }
}