﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Halloween_MVC_1.Models;
using Halloween_MVC_1.Models.ViewModels;

namespace Halloween_MVC_1.Controllers
{
    public class ConfirmController : Controller
    {
        private readonly CartModel cart = new CartModel();

        // GET: Confirm
        public ActionResult Index()
        {
            CartViewModel model = (CartViewModel) TempData["cart"];
            if (model == null)
                model = cart.GetCart();
            return View(model);
        }
    }
}