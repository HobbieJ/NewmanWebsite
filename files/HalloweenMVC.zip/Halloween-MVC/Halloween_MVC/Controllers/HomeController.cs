﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Halloween_MVC_1.Models;

namespace Halloween_MVC_1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            ViewBag.HeaderText = "Welcome to the Halloween store.";
            ViewData["FooterText"] = "Where every day is Halloween!";
            return View();
        }
        public ActionResult Contact()
        {
            ContactModel model = new ContactModel();
            return View(model);
        }

        public ActionResult Confirmed()
        {
            return View();
        }
    }
}