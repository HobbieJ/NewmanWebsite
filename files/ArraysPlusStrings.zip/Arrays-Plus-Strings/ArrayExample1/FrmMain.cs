﻿/*************************************************************************************/
/* Jacob Hobbie                                                                      */
/* May 20th 2015                                                                     */
/* ProgrammingOneSubmit, FrmMain.cs                                                  */
/* Programming I                                                                     */
/*                                                                                   */
/* Takes an employee's name and their salary as input.  The program then finds the   */
/* employee's name from their full name, displays it in a professional format, and   */
/* also displays the employee's salary, and the salary's deviation from the average. */
/* The program supports alt-keys and the Accept and Cancel button, with btnCalculate */
/* and btnClear being the values of those two respectively.                          */
/*************************************************************************************/

using System;
using System.Windows.Forms;

// ReSharper disable FieldCanBeMadeReadOnly.Local
// ReSharper disable StringIndexOfIsCultureSpecific.1
// ReSharper disable JoinDeclarationAndInitializer
// ReSharper disable StringLastIndexOfIsCultureSpecific.1

namespace EmployeeDeviation
{
    public partial class FrmMain : Form
    {
        /// <globalVars>
        /// MAXNUM - A constant variable that holds the number of entries this
        /// program will accept.
        /// dblSum - Sum of all values entered in order to find the average
        /// of the scores provided.
        /// intCount - How many numbers are entered into the array by the user.
        /// strOutput - A string that is entered into rchTxtBxOutput
        /// to show the results of btnCalculate.
        /// dblScores[] - A double array that holds the total scores individually
        /// from the user.
        /// strFirstNames[] - A string array that holds the first name of the individual's
        /// score.
        /// strLastName[] - A string array that holds the last name of the individual's
        /// score.
        /// strMiddleInit[] - A string array that holds the middle name of the individual's
        /// score.
        /// </globalVars>

        #region GlobalVars
        const int MAXNUM = 100;
        double dblSum;
        int intCount;
        string strOutput;
        double[] dblSalaries = new double[MAXNUM];
        string[] strFirstNames = new string[MAXNUM];
        string[] strLastNames = new string[MAXNUM];
        string[] strMiddleInit = new string[MAXNUM];
        #endregion

        // Starts the Windows Form with InitializeComponent() and starts
        // the application with txtBxScore focused for the user to enter
        // data.
        public FrmMain()
        {
            InitializeComponent();
            ActiveControl = txtBxName;
        }

        #region Events
        // Takes data from the user, and attempts to enter it into their respective
        // arrays.
        private void btnEnterData_Click(object sender, EventArgs e)
        {
            try
            {
                string strSalary = txtBxSalary.Text;
                double dblSalary = Convert.ToDouble(strSalary);
                try
                {
                    dblSalaries[intCount] = dblSalary;
                    DivideNames();
                    intCount++;
                    dblSum += dblSalary;
                    MessageBox.Show("The Employee has been entered", "Successful Entry");
                    txtBxName.Text = "";
                    txtBxSalary.Text = "";
                    ActiveControl = txtBxName;
                }
                catch (IndexOutOfRangeException)
                {
                    string strMessage = "You have entered " + MAXNUM + " values.  The" +
                                        " array is full.";
                    btnEnterData.Enabled = false;
                    MessageBox.Show(strMessage, "Error", MessageBoxButtons.OK, 
                        MessageBoxIcon.Error);
                    txtBxName.Text = "";
                    txtBxSalary.Text = "";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("You must enter a salary", "Error");
                txtBxSalary.SelectAll();
                ActiveControl = txtBxSalary;
            }
        }

        // Takes scores and names from user-entered data and inputs them into
        // a string that is sent to FrmDisplay.
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double dblAverage = dblSum / intCount;
            strOutput = "Name".PadRight(25) + "Salary".PadLeft(18) + "Dev. from Avg"
            .PadLeft(23) + "\n\n";

            for (int i = 0; i < intCount; i++)
            {
                double dblDeviation = dblSalaries[i] - dblAverage;
                string strFullName = strLastNames[i] + ", " + strFirstNames[i] +
                    strMiddleInit[i];
                strOutput += strFullName.PadRight(25) + 
                    dblSalaries[i].ToString("C2").PadLeft(18) + 
                    dblDeviation.ToString("C2").PadLeft(23) + "\n";
            }
            FrmDisplay aDisplayForm = new FrmDisplay(strOutput);
            aDisplayForm.ShowDialog();
        }

        // Clears all Text Boxes, global variables, and user entered data in
        // arrays to completely reset program.
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtBxSalary.Text = "";
            txtBxName.Text = "";
            intCount = 0;
            dblSum = 0;
            strOutput = "";
            ActiveControl = txtBxName;
            // btnDataEnter made sure to be enabled when program reset.
            btnEnterData.Enabled = true;
        }

        // Shows FrmAbout
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAbout anAboutForm = new FrmAbout();
            anAboutForm.ShowDialog();
        }
        #endregion

        // Finds all parts of employee's name from one main name
        private void DivideNames()
        {
            int intIndexPeriod;
            int intIndexFirstSpace;

            string strName = txtBxName.Text;
            // Finds First Name
            intIndexFirstSpace = strName.IndexOf(" ");
            strFirstNames[intCount] = strName.Substring(0, intIndexFirstSpace);
            // Finds Middle Initials, (If there)
            intIndexPeriod = strName.IndexOf(".");
            if (intIndexPeriod != -1)
            {
                strMiddleInit[intCount] = " " + strName.Substring(intIndexPeriod - 1, 2);
                // Finds Last Name
                strLastNames[intCount] = strName.Substring(intIndexPeriod + 2);
            }
            else
            {
                // Happens if No Middle Initial
                strLastNames[intCount] = strName.Substring(intIndexFirstSpace + 1);
            }
        }
    }
}
