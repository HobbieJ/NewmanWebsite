﻿namespace EmployeeDeviation
{
    partial class FrmAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAbout));
            this.picBxMe = new System.Windows.Forms.PictureBox();
            this.lblAbout = new System.Windows.Forms.Label();
            this.lnkLblWebsite = new System.Windows.Forms.LinkLabel();
            this.toolAbout = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picBxMe)).BeginInit();
            this.SuspendLayout();
            // 
            // picBxMe
            // 
            this.picBxMe.Image = global::EmployeeDeviation.Properties.Resources.Jacob_Hobbie;
            this.picBxMe.Location = new System.Drawing.Point(12, 12);
            this.picBxMe.Name = "picBxMe";
            this.picBxMe.Size = new System.Drawing.Size(192, 192);
            this.picBxMe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBxMe.TabIndex = 0;
            this.picBxMe.TabStop = false;
            // 
            // lblAbout
            // 
            this.lblAbout.AutoSize = true;
            this.lblAbout.Location = new System.Drawing.Point(210, 12);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(371, 80);
            this.lblAbout.TabIndex = 1;
            this.lblAbout.Text = "Developed by Jacob Hobbie\r\nVersion 2.0.0\r\nCopyright 2015\r\nDeveloped for Programmi" +
    "ng I at Newman University";
            // 
            // lnkLblWebsite
            // 
            this.lnkLblWebsite.AutoSize = true;
            this.lnkLblWebsite.Location = new System.Drawing.Point(210, 184);
            this.lnkLblWebsite.Name = "lnkLblWebsite";
            this.lnkLblWebsite.Size = new System.Drawing.Size(180, 20);
            this.lnkLblWebsite.TabIndex = 2;
            this.lnkLblWebsite.TabStop = true;
            this.lnkLblWebsite.Text = "Jacob Hobbie\'s Website";
            this.toolAbout.SetToolTip(this.lnkLblWebsite, "Will open a browser window\r\nEx. Internet Explorer or Chrome");
            this.lnkLblWebsite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkLblWebsite_LinkClicked);
            // 
            // FrmAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 220);
            this.Controls.Add(this.lnkLblWebsite);
            this.Controls.Add(this.lblAbout);
            this.Controls.Add(this.picBxMe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmAbout";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About";
            this.Load += new System.EventHandler(this.FrmAbout_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBxMe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBxMe;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.LinkLabel lnkLblWebsite;
        private System.Windows.Forms.ToolTip toolAbout;
    }
}