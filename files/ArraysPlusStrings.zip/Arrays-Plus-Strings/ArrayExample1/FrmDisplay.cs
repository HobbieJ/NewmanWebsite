﻿/*************************************************************************************/
/* Jacob Hobbie                                                                      */
/* May 20th 2015                                                                     */
/* ProgrammingOneSubmit, FrmDisplay.cs                                               */
/* Programming I                                                                     */
/*                                                                                   */
/* FrmDisplay takes a string generated from FrmMain and fills the screen with the    */
/* data sent to display to the user.                                                 */
/*************************************************************************************/

using System;
using System.Windows.Forms;

namespace EmployeeDeviation
{
    public partial class FrmDisplay : Form
    {
        // Takes string generated from FrmMain and displays it in FrmDisplay
        public FrmDisplay(string display)
        {
            InitializeComponent();
            rchTxtBxDisplay.Text = display;
        }

        // Closes FrmDisplay
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
