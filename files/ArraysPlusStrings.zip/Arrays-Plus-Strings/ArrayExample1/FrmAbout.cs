﻿/*************************************************************************************/
/* Jacob Hobbie                                                                      */
/* May 20th 2015                                                                     */
/* ProgrammingOneSubmit, FrmAbout.cs                                                 */
/* Programming I                                                                     */
/*                                                                                   */
/* Shows FrmAbout, which gives a brief description of the programmer, the purpose of */
/* the program, and a link to the programmer's website.                              */
/*************************************************************************************/

using System;
using System.Diagnostics;
using System.Windows.Forms;

// ReSharper disable AssignNullToNotNullAttribute

namespace EmployeeDeviation
{
    public partial class FrmAbout : Form
    {
        public FrmAbout()
        {
            InitializeComponent();
        }

        #region Events
        // Prepares form to accept lnkLblWebsite Click
        private void FrmAbout_Load(object sender, EventArgs e)
        {
            LinkLabel.Link websiteLink = new LinkLabel.Link();
            websiteLink.LinkData = "http://www.jacobhobbie.com/";
            lnkLblWebsite.Links.Add(websiteLink);
        }

        // Starts new web process
        private void lnkLblWebsite_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (e != null) Process.Start(e.Link.LinkData as string);
        }
        #endregion
    }
}
